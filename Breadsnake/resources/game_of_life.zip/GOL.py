"""
Författare: Mille Kåge
Datum: 11/4 2021
"""


class Cell:
    # Denna klass beskriver varje cell i matrisen.

    def __init__(self, x_pos, y_pos, alive):
        self.x_pos = x_pos  # Cellens x-koordinat
        self.y_pos = y_pos  # Cellens y-koordinat
        self.alive = alive  # Om cellen lever eller är död
        self.neighbor_amount = 0  # Hur många grannar cellen har
        self.check = False  # Om man ska räkna (checka) på cellen

    def calc_alive(self):
        # Denna metod räknar ut om cellen kommer att leva/dö utifrån reglerna i Game of Life

        if self.alive is True and (self.neighbor_amount == 2 or self.neighbor_amount == 3):
            self.alive = True

        elif self.alive is False and self.neighbor_amount == 3:
            self.alive = True

        elif self.neighbor_amount > 3:
            self.alive = False

        elif self.neighbor_amount < 2:
            self.alive = False


def read_cells_from_file(file_name):
    # Läser in en fil och returnerar innehållet

    fr = open(file_name, "r")
    existing_cells = fr.read()
    fr.close()
    return existing_cells


def create_cells(existing_cells):
    """
    Denna funktion skapar alla celler. Om filen
    anger att en cell lever sätts dess alive attribut till True.
    Funktionen returnerar en nestad lista med alla cell-objekt
    där listans index är cellens x/y koordinat.
    """

    existing_cells = existing_cells.splitlines()

    cells = []
    for y in range(n):
        temp = []
        for x in range(m):
            temp.append(Cell(x, y, False))
        cells.append(temp)

    for y in range(n):
        for x in range(m):
            if (str(y + 1) + " " + str(x + 1)) in existing_cells:
                cells[x][y].alive = True

    return cells


def check_cells(x, y):
    """
    Denna funktion får in ett x och y värde som representerar en cell.
    Sedan sätts alla grannar (inklusive cellen) till check = True
    """

    for y_neighbor in range(-1, 2):
        for x_neighbor in range(-1, 2):
            x_check = x
            y_check = y

            # Om index blir större än storleken på matrisen går man till andra sidan
            if x_check + x_neighbor > m - 1:
                x_check = -1

            if y_check + y_neighbor > n - 1:
                y_check = -1

            cells[x_check + x_neighbor][y_check + y_neighbor].check = True


def calc_neighbors(x, y):
    """
    Denna funktion får in ett x och y värde som representerar en cell.
    Syftet med funktionen är att beräkna hur många av cellens grannar
    som lever och sedan addera det talet till cellens neighbor_amount.
    """

    cells[x][y].neighbor_amount = 0

    for y_neighbor in range(-1, 2):
        for x_neighbor in range(-1, 2):
            x_check = x
            y_check = y

            if (x_check + x_neighbor) > m - 1:
                x_check = -1

            if (y_check + y_neighbor) > n - 1:
                y_check = -1

            if cells[x_check + x_neighbor][y_check + y_neighbor].alive:
                cells[x][y].neighbor_amount += 1

    # Om cellen i fråga redan lever vill vi inte ha med det i neighbor_amount.
    if cells[x][y].alive:
        cells[x][y].neighbor_amount -= 1


def clear_board():
    # Denna funktion dödar alla celler

    for y in range(n):
        for x in range(m):
            cells[x][y].alive = False


def draw_board():
    # Denna funktion ritar ut matrisen med hänsyn till om cellerna lever eller inte

    for y in range(n):
        for x in range(m):
            if cells[x][y].alive:
                print("* ", end="")
            else:
                print("- ", end="")

        print("\n", end="")


def input_generation(prompt):
    # Denna funktion låter användaren skriva in ett tal och felhanterar inputen.

    done = False
    while done is False:
        value = input(prompt)
        try:
            int(value)
            done = True
        except ValueError:
            print("Please write a number")
    return int(value)


def update(gen_number):
    """
    Denna funktion beräknar vad som händer med cellerna
    efter varje generation. Talet gen_number anger hur
    många gånger beräkningarna ska ske.
    """

    for gen in range(gen_number):

        # Utför check_cells på alla celler som lever.
        for y in range(n):
            for x in range(m):
                if cells[x][y].alive:
                    check_cells(x, y)

        # Beräknar hur många grannar alla celler med check = True har.
        for y in range(n):
            for x in range(m):
                if cells[x][y].check:
                    calc_neighbors(x, y)

        # Utför calc_alive på alla celler med check = True.
        for y in range(n):
            for x in range(m):
                if cells[x][y].check:
                    cells[x][y].calc_alive()

        # Sätter alla cellers check till False
        for y in range(n):
            for x in range(m):
                cells[x][y].check = False


def main():
    # Denna funktion utför själva algoritmen

    while True:
        draw_board()
        gen_number = input_generation("How many generations should go by?: ")
        update(gen_number)


n = 10  # Storlek i y-ritning
m = 10  # Storlek i x-ritning
file_data = str()
file_data = read_cells_from_file("glidare.txt")
cells = create_cells(file_data)

if __name__ == '__main__':
    main()
