"""
Författare: Mille Kåge
Datum: 11/4 2021
"""

from tkinter import *
import GOL


class Application(Frame):
    """ GUI application that creates a story based on user input. """

    def __init__(self, master):
        """ Initialize Frame. """
        Frame.__init__(self, master)
        self.grid()
        self.create_widgets()

    def create_widgets(self):
        self.button = []
        for y in range(GOL.n):
            temp = []
            for x in range(GOL.m):
                if GOL.cells[x][y].alive:
                    temp.append(Button(self,
                                       width=2,
                                       height=1,
                                       command=lambda x_button=x, y_button=y: self.change_color(y_button, x_button),
                                       bg="black"
                                       ))
                    temp[x].grid(row=y, column=x, sticky=W)
                else:
                    temp.append(Button(self,
                                       width=2,
                                       height=1,
                                       command=lambda x_button=x, y_button=y: self.change_color(y_button, x_button),
                                       bg="white"
                                       ))
                    temp[x].grid(row=y, column=x, sticky=W)
            self.button.append(temp)

        Label(self,
              text="Welcome to the Game of Life!"
              ).grid(row=0, column=GOL.m + 1, columnspan=2,
                     sticky=W)

        Label(self,
              text="",
              width=2
              ).grid(row=0, column=GOL.m + 3, columnspan=2,
                     sticky=W)

        Label(self,
              text="Number of generations:"
              ).grid(row=1, column=GOL.m + 1, sticky=W)

        self.gen_input = Entry(self)
        self.gen_input.grid(row=1, column=GOL.m + 2, sticky=W)

        Button(self,
               text="Next generation/s",
               command=self.calc_gen
               ).grid(row=2, column=GOL.m + 1, sticky=W)

        Button(self,
               text="Clear",
               command=self.clear_board
               ).grid(row=2, column=GOL.m + 2, sticky=W)

        Label(self,
              text="Instructions:",
              font =("Arial", 9, "underline")
              ).grid(row=4, column=GOL.m + 1, columnspan=2,
                     sticky=W)

        Label(self,
              text="1. Click on the squares to kill/revive cells"
              ).grid(row=5, column=GOL.m + 1, columnspan=2,
                     sticky=W)

        Label(self,
              text="2. Input the number of generations that should pass"
              ).grid(row=6, column=GOL.m + 1, columnspan=2,
                     sticky=W)

        Label(self,
              text="3. Press 'Next genetations/s' to witness the game of life"
              ).grid(row=7, column=GOL.m + 1, columnspan=2,
                     sticky=W)

    def calc_gen(self):
        if self.get_gen():
            GOL.update(int(self.gen_input.get()))

            for y in range(GOL.n):
                for x in range(GOL.m):
                    if GOL.cells[x][y].alive:
                        self.button[y][x].config(bg="black")

                    else:
                        self.button[y][x].config(bg="white")

    def get_gen(self):
        self.gen_number = self.gen_input.get()
        try:
            int(self.gen_number)
            return True
        except ValueError:
            self.gen_input.delete(0, END)
            self.gen_input.insert(0, "Please write a number")
            return False

    def clear_board(self):
        for y in range(GOL.n):
            for x in range(GOL.m):
                self.button[y][x].config(bg="white")
                GOL.cells[x][y].alive = False

    def change_color(self, y, x):
        if self.button[y][x].cget("bg") == "white":
            self.button[y][x].config(bg="black")
            GOL.cells[x][y].alive = True
            return

        if self.button[y][x].cget("bg") == "black":
            self.button[y][x].config(bg="white")
            GOL.cells[x][y].alive = False
            return


# main
root = Tk()
root.title("Game of Life")
app = Application(root)
root.mainloop()
